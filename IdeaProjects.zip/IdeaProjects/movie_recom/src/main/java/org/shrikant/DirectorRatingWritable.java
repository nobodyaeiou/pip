package org.shrikant;

import org.apache.hadoop.io.*;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public class DirectorRatingWritable implements Writable {
    private Text director;
    private DoubleWritable rating;

    public DirectorRatingWritable() {
        director = new Text();
        rating = new DoubleWritable();
    }

    public DirectorRatingWritable(Text director, DoubleWritable rating) {
        this.director = director;
        this.rating = rating;
    }

    @Override
    public void write(DataOutput out) throws IOException {
        director.write(out);
        rating.write(out);
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        director.readFields(in);
        rating.readFields(in);
    }

    public Text getDirector() {
        return director;
    }

    public DoubleWritable getRating() {
        return rating;
    }
}
