package org.shrikant;

import java.io.IOException;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;

public class StopWordCountMapper extends Mapper<LongWritable, Text, IntWritable, Text> {
    private final static IntWritable length = new IntWritable(0);
    private Text word = new Text();

    // Define your stop words
    private static final String[] stopWords = {"the", "and", "is", "of", "it", "in", "to"};

    @Override
    protected void map(LongWritable key, Text value, Context context)
            throws IOException, InterruptedException {
        String[] words = value.toString().toLowerCase().split("\\s+");

        for (String word : words) {
            // Check if the word is a stop word
            if (isStopWord(word)) {
                length.set(word.length());
                this.word.set(word);
                context.write(length, this.word);
            }
        }
    }

    private boolean isStopWord(String word) {
        for (String stopWord : stopWords) {
            if (word.equals(stopWord)) {
                return true;
            }
        }
        return false;
    }
}
