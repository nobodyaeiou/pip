package org.shrikant;

import java.io.IOException;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;

public class WeatherAnalysisMapper extends Mapper<LongWritable, Text, Text, Text> {
    private Text date = new Text();
    private Text weatherCondition = new Text();

    @Override
    protected void map(LongWritable key, Text value, Context context)
            throws IOException, InterruptedException {
        String[] fields = value.toString().split(",");

        if (fields.length >= 2 && !fields[0].isEmpty() && !fields[1].isEmpty()) {
            date.set(fields[0]);
            weatherCondition.set(fields[1]);
            context.write(date, weatherCondition);
        }
    }
}
