package org.shrikant;

import java.io.IOException;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;

public class WeatherAnalysisReducer extends Reducer<Text, Text, Text, Text> {
    private Text result = new Text();

    @Override
    protected void reduce(Text key, Iterable<Text> values, Context context)
            throws IOException, InterruptedException {
        int sunnyCount = 0;
        int coldCount = 0;

        for (Text value : values) {
            String condition = value.toString().toLowerCase();

            if (condition.contains("sunny")) {
                sunnyCount++;
            } else if (condition.contains("cold")) {
                coldCount++;
            }
        }

        String analysisResult;
        if (sunnyCount > coldCount) {
            analysisResult = "Sunny Day";
        } else if (coldCount > sunnyCount) {
            analysisResult = "Cold Day";
        } else {
            analysisResult = "Neutral Day";
        }

        result.set("Sunny Count: " + sunnyCount + ", Cold Count: " + coldCount + ", Analysis: " + analysisResult);
        context.write(key, result);
    }
}
