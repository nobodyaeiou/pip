package org.shrikant;

public class reducer {
}
