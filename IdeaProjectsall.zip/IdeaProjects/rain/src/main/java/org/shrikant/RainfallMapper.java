package org.shrikant;

import java.io.IOException;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;

public class RainfallMapper extends Mapper<LongWritable, Text, Text, DoubleWritable> {
    private Text year = new Text();
    private DoubleWritable rainfall = new DoubleWritable();

    @Override
    protected void map(LongWritable key, Text value, Context context)
            throws IOException, InterruptedException {
        String[] fields = value.toString().split(",");

        if (fields.length >= 2 && !fields[0].isEmpty() && !fields[1].isEmpty()) {
            String date = fields[0].trim();
            double tempRainfall = Double.parseDouble(fields[1].trim());

            // Extract the year from the date (assuming the date is in YYYY-MM-DD format)
            String currentYear = extractYear(date);

            year.set(currentYear);
            rainfall.set(tempRainfall);
            context.write(year, rainfall);
        }
    }

    private String extractYear(String date) {
        // Extract the year from the date (assuming the date is in YYYY-MM-DD format)
        // You may need to adjust this logic based on your dataset's date format
        return date.substring(0, 4);
    }
}
