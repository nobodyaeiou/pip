package org.shrikant;

import java.io.IOException;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;

public class RainfallReducer extends Reducer<Text, DoubleWritable, Text, DoubleWritable> {
    private DoubleWritable result = new DoubleWritable();

    @Override
    protected void reduce(Text key, Iterable<DoubleWritable> values, Context context)
            throws IOException, InterruptedException {
        double totalRainfall = 0.0;

        for (DoubleWritable value : values) {
            totalRainfall += value.get();
        }

        result.set(totalRainfall);
        context.write(key, result);
    }
}
