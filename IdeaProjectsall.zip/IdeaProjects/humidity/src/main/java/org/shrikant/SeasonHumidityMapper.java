package org.shrikant;

import java.io.IOException;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;

public class SeasonHumidityMapper extends Mapper<LongWritable, Text, Text, DoubleWritable> {
    private Text season = new Text();
    private DoubleWritable humidity = new DoubleWritable();

    @Override
    protected void map(LongWritable key, Text value, Context context)
            throws IOException, InterruptedException {
        String[] fields = value.toString().split(",");

        if (fields.length >= 2 && !fields[0].isEmpty() && !fields[1].isEmpty()) {
            String currentSeason = fields[0].trim(); // Assuming the season is in the first column
            double tempHumidity = Double.parseDouble(fields[1].trim());

            season.set(currentSeason);
            humidity.set(tempHumidity);
            context.write(season, humidity);
        }
    }
}
