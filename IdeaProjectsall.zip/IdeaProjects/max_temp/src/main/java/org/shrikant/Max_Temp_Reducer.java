package org.shrikant;
import java.io.IOException;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;
public class Max_Temp_Reducer extends Reducer <Text,Text,Text,Text> {
    private Text result = new Text();
    @Override
    protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
        double sum = 0.0;
        int count = 0;
        double max_temp = Double.MIN_VALUE;
        double p_temp = Double.MIN_VALUE;
        String maxtmp = "";
        String trend = "";
        for (Text value : values) {
            String[] parts = value.toString().split(":");
            if (parts.length == 1) {
                try {
                    double temp = Double.parseDouble(parts[0]);
                    sum += temp;
                    count++;
                    if (temp > max_temp) {
                        max_temp = temp;
                        maxtmp = parts[0];
                    }
                    if(temp < p_temp){
                        trend = "Increasing";
                    }
                    else if(temp > p_temp){
                        trend = "Decreasing";
                    }
                    else{
                        trend = "Stable";
                    }
                    p_temp = temp;

                } catch (NumberFormatException e) {
                }
            }
        }
        if (count > 0) {
            double averageTemp = sum / count;
            result.set("Average Temperature : " + averageTemp + ", Maximum Temperature : " + maxtmp + trend);
            context.write(key, result);
        }
    }
}
