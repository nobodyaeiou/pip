package org.shrikant;

import java.io.IOException;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;


public class Max_Temp_Mapper extends Mapper<LongWritable, Text, Text, Text> {
    private Text outputKey = new Text();
    private Text outputValue = new Text();

    @Override
    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        // Assuming the input format is comma-separated
        String[] fields = value.toString().split(",");

        if (fields.length >= 2 && !fields[0].isEmpty() && !fields[1].isEmpty()) {
            String year = fields[0].substring(6, 10);
            String temp = fields[1].trim();

            try {
                outputKey.set(year);
                outputValue.set(temp);
                context.write(outputKey, outputValue);
            } catch (NumberFormatException e) {
                // Handle parsing errors
            }
        }
    }
}
