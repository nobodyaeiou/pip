package org.shrikant;

import java.io.IOException;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;

public class StudentGradeReducer extends Reducer<Text, Text, Text, Text> {
    private Text result = new Text();

    @Override
    protected void reduce(Text key, Iterable<Text> values, Context context)
            throws IOException, InterruptedException {
        double sum = 0.0;
        int count = 0;

        for (Text value : values) {
            try {
                double score = Double.parseDouble(value.toString());
                sum += score;
                count++;
            } catch (NumberFormatException e) {
                // Handle parsing errors
            }
        }

        if (count > 0) {
            double averageScore = sum / count;
            String grade = calculateGrade(averageScore);
            result.set("Average Score: " + averageScore + ", Grade: " + grade);
            context.write(key, result);
        }
    }

    private String calculateGrade(double averageScore) {
        // Implement your logic to determine grades based on average score
        // Example: A, B, C, D, F
        if (averageScore >= 90) {
            return "A";
        } else if (averageScore >= 80) {
            return "B";
        } else if (averageScore >= 70) {
            return "C";
        } else if (averageScore >= 60) {
            return "D";
        } else {
            return "F";
        }
    }
}
